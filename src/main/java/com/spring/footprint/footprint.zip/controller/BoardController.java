package com.spring.footprint.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spring.footprint.service.AdminBoardListVO;
import com.spring.footprint.service.AdminBoardService;
import com.spring.footprint.service.AdminTipBoardListVO;
import com.spring.footprint.service.AdminTipBoardService;
import com.spring.footprint.service.MemberTipBoardListVO;
import com.spring.footprint.service.MemberTipBoardService;

@Controller
public class BoardController {
	@Resource
	private MemberTipBoardService memberTipBoardService;
	@Resource
	private AdminTipBoardService adminTipBoardService;
	@Resource
	private AdminBoardService adminBoardService;
	
	@RequestMapping("TipBoard.do")
	public ModelAndView TipBoard(String ApageNo, String MpageNo) throws Exception{
		MemberTipBoardListVO memberTipBoardListVO = memberTipBoardService.getMemberTipBoardList(MpageNo);
		
		AdminTipBoardListVO adminTipBoardListVO = adminTipBoardService.getAdminTipBoardList(ApageNo);
		System.out.println("adminTipBoardListVO::"+adminTipBoardListVO);
		System.out.println("memberTipBoardListVO::"+memberTipBoardListVO);
		ModelAndView mv = new ModelAndView();
		mv.addObject("memberTipBoardListVO", memberTipBoardListVO);
		mv.addObject("adminTipBoardListVO", adminTipBoardListVO);
		mv.setViewName("show_tip_list");
		return mv;
	}
	
	@RequestMapping("NoticeBoard.do")
	public ModelAndView NoticeBoard(String pageNo) throws Exception{
		AdminBoardListVO adminBoardListVO = adminBoardService.getAdminBoardList(pageNo);
		System.out.println("adminBoardListVO::"+adminBoardListVO);
		ModelAndView mv = new ModelAndView();
		mv.addObject("adminBoardListVO", adminBoardListVO);
		mv.setViewName("show_notice_list");
		return mv;/*new ModelAndView("show_notice_list", "adminBoardListVO", adminBoardListVO);*/
	}

}
